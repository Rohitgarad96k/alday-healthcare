import React from 'react';

const BundleSection = () => {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-[1200px] mx-auto px-6">
        
        {/* BUNDLE 1: Hair Growth (Image Left, Text Right) */}
        <div className="flex flex-col md:flex-row items-center gap-12 mb-32">
          {/* Left: Big Image */}
          <div className="w-full md:w-1/2 relative bg-[#F9F9F9] p-10 rounded-lg">
             {/* Placeholder for the big kit image */}
            <img 
              src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80" 
              alt="Hair Growth Kit" 
              className="w-full h-auto object-contain mix-blend-multiply"
            />
            {/* The Floating Dots seen in screenshot */}
            <div className="absolute top-1/2 left-1/3 w-4 h-4 bg-gray-800 rounded-full border-2 border-white cursor-pointer hover:scale-125 transition-transform"></div>
          </div>

          {/* Right: Product List */}
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-bold uppercase tracking-wide mb-10 text-brand-black">
              Hair Growth Bundle
            </h2>

            {/* List Items */}
            <div className="space-y-8 mb-10">
              {[
                { name: "Rosemary Oil Shots For Visible Hair Growth", price: "795.00" },
                { name: "Rosemary Shampoo for Visible Hair Growth", price: "595.00" },
                { name: "Rosemary & Redensyl Scalp Serum", price: "995.00" }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-4 border-b border-gray-100 pb-4">
                  <div className="w-16 h-16 bg-gray-50 rounded-md overflow-hidden flex-shrink-0">
                    <img src="https://images.unsplash.com/photo-1608248597279-f99d160bfbc8?w=100" className="w-full h-full object-cover"/>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm text-gray-600 font-medium">{item.name}</h4>
                  </div>
                  <span className="text-sm font-medium text-gray-900">₹{item.price}</span>
                </div>
              ))}
            </div>

            <button className="w-full bg-brand-black text-white py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-gray-800 transition-all">
              Add Set To Cart
            </button>
          </div>
        </div>

        {/* BUNDLE 2: Brightening (Text Left, Image Right) */}
        <div className="flex flex-col md:flex-row-reverse items-center gap-12">
          {/* Right: Big Image */}
          <div className="w-full md:w-1/2 relative bg-[#F9F9F9] p-10 rounded-lg">
            <img 
              src="https://images.unsplash.com/photo-1556228720-191738e4a2e5?auto=format&fit=crop&w=800&q=80" 
              alt="Brightening Kit" 
              className="w-full h-auto object-contain mix-blend-multiply"
            />
          </div>

          {/* Left: Product List */}
          <div className="w-full md:w-1/2">
            <h2 className="text-3xl font-bold uppercase tracking-wide mb-10 text-brand-black">
              Brightening Bundle
            </h2>

            <div className="space-y-8 mb-10">
              {[
                { name: "Vitamin C Powder Face Wash", price: "495.00" },
                { name: "10% Vitamin C Face Serum", price: "895.00" },
                { name: "Vitamin C Liquid Moisturizer", price: "695.00" }
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-4 border-b border-gray-100 pb-4">
                  <div className="w-16 h-16 bg-gray-50 rounded-md overflow-hidden flex-shrink-0">
                    <img src="https://images.unsplash.com/photo-1629198688000-71f23e745b6e?w=100" className="w-full h-full object-cover"/>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm text-gray-600 font-medium">{item.name}</h4>
                  </div>
                  <span className="text-sm font-medium text-gray-900">₹{item.price}</span>
                </div>
              ))}
            </div>

            <button className="w-full bg-brand-black text-white py-4 text-xs font-bold uppercase tracking-[0.2em] hover:bg-gray-800 transition-all">
              Add Set To Cart
            </button>
          </div>
        </div>

      </div>
    </section>
  );
};

export default BundleSection;