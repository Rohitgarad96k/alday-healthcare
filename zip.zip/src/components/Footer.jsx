import React from 'react';
import { Facebook, Instagram, Linkedin, Youtube, Truck } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-white text-gray-800 pt-20 pb-10 border-t border-gray-200">
      <div className="max-w-[1400px] mx-auto px-6">
        
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 mb-16">
          
          {/* Column 1: About Us (Width: 4/12) */}
          <div className="md:col-span-4 pr-8">
            <h5 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">About Us</h5>
            
            <div className="mb-6">
              <span className="text-2xl font-bold tracking-widest text-brand-black">
                ALDAY<span className="font-light">HEALTH</span>
              </span>
            </div>

            <h4 className="font-bold mb-4 text-sm">
              At Alday, we believe in the power of superior ingredients to deliver exceptional results.
            </h4>
            
            <p className="text-sm text-gray-500 leading-relaxed mb-6">
              Our products are crafted with the finest natural, high-performance ingredients, 
              meticulously selected to ensure purity, potency, and effectiveness.
            </p>

            <h5 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-4">Follow Us</h5>
            <div className="flex gap-4">
               <div className="w-10 h-10 border border-black rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors"><Facebook size={18}/></div>
               <div className="w-10 h-10 border border-black rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors"><Instagram size={18}/></div>
               <div className="w-10 h-10 border border-black rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors"><Linkedin size={18}/></div>
               <div className="w-10 h-10 border border-black rounded-full flex items-center justify-center hover:bg-black hover:text-white transition-colors"><Youtube size={18}/></div>
            </div>
          </div>

          {/* Column 2: Explore (Width: 3/12) */}
          <div className="md:col-span-3">
             <h5 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Explore</h5>
             <ul className="space-y-3 text-sm text-gray-600">
               {['All Products', 'Hair Care Products', 'Skin Care Products', 'Body Care Products', 'Our Story', 'Corporate Gifting', 'Reviews', 'Blogs'].map(item => (
                 <li key={item}><a href="#" className="hover:text-brand-gold transition-colors">{item}</a></li>
               ))}
             </ul>
          </div>

          {/* Column 3: Address (Width: 5/12) */}
          <div className="md:col-span-5">
             <h5 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-6">Address</h5>
             <div className="text-sm text-gray-600 space-y-1 mb-8">
               <p>Alday Health Science Ltd.</p>
               <p>D-1306, Tech Park, </p>
               <p>Near Hinjewadi Circle,</p>
               <p>Pune - 411057, Maharashtra, India.</p>
             </div>

             <div className="mb-6">
               <h6 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Phone</h6>
               <p className="text-sm text-gray-600">+91 95123 33000</p>
             </div>

             <div>
               <h6 className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-2">Email</h6>
               <p className="text-sm text-gray-600">customercare@aldayhealth.com</p>
             </div>
          </div>

        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-gray-100 flex flex-col md:flex-row justify-between items-center text-xs text-gray-400">
          <p>© 2026 Alday Health Care. All rights reserved.</p>
        </div>

      </div>
    </footer>
  );
};

export default Footer;