import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, ShoppingCart, Eye } from 'lucide-react';

const products = [
  {
    id: 1,
    vendor: 'Brillare',
    name: 'Rosemary Oil Shots',
    concern: 'Hair Growth',
    size: '6ml x 8',
    price: 795.00,
    mrp: 795.00,
    image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfbc8?auto=format&fit=crop&w=600&q=80',
    sale: false
  },
  {
    id: 2,
    vendor: 'Brillare',
    name: 'Onion & Bakuchiol Oil',
    concern: 'Hair Fall Control',
    size: '6ml x 8',
    price: 795.00,
    mrp: 795.00,
    image: 'https://images.unsplash.com/photo-1629198688000-71f23e745b6e?auto=format&fit=crop&w=600&q=80',
    sale: false
  },
  {
    id: 3,
    vendor: 'Brillare',
    name: 'Argan Oil Shots',
    concern: 'Dry, Frizzy Hair',
    size: '6ml x 8',
    price: 795.00,
    mrp: 795.00,
    image: 'https://images.unsplash.com/photo-1556228578-8d8448ad1d4d?auto=format&fit=crop&w=600&q=80',
    sale: false
  },
  {
    id: 4,
    vendor: 'Brillare',
    name: 'Tea Tree Oil Shots',
    concern: 'Dandruff Control',
    size: '6ml x 8',
    price: 650.00,
    mrp: 795.00,
    image: 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=600&q=80',
    sale: true
  },
  {
    id: 5,
    vendor: 'Brillare',
    name: 'Vitamin C Serum',
    concern: 'Skin Brightening',
    size: '30ml',
    price: 895.00,
    mrp: 895.00,
    image: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?auto=format&fit=crop&w=600&q=80',
    sale: false
  },
  {
    id: 6,
    vendor: 'Brillare',
    name: 'Salicylic Acid Serum',
    concern: 'Acne Control',
    size: '30ml',
    price: 595.00,
    mrp: 795.00,
    image: 'https://images.unsplash.com/photo-1556228720-191738e4a2e5?auto=format&fit=crop&w=600&q=80',
    sale: true
  }
];

const ProductSection = () => {
  const [startIndex, setStartIndex] = useState(0);
  
  // Configuration
  const visibleItems = 4; // Number of items to show at once on desktop
  const cardWidth = 100 / visibleItems; 

  const nextSlide = () => {
    if (startIndex < products.length - visibleItems) {
      setStartIndex(startIndex + 1);
    } else {
      setStartIndex(0); // Loop back to start
    }
  };

  const prevSlide = () => {
    if (startIndex > 0) {
      setStartIndex(startIndex - 1);
    } else {
      setStartIndex(products.length - visibleItems); // Loop to end
    }
  };

  return (
    <div className="bg-white py-16 relative group">
      <div className="max-w-[1400px] mx-auto px-6 overflow-hidden">
        
        {/* Header */}
        <div className="text-center mb-12">
          <h2 className="text-2xl md:text-3xl font-bold uppercase tracking-wider text-gray-900">
            Super Powerful Hair Oils
          </h2>
        </div>

        {/* Carousel Container */}
        <div className="relative">
          
          {/* Navigation Buttons (Visible on Hover) */}
          <button 
            onClick={prevSlide}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 disabled:opacity-30 hover:bg-gray-50 border border-gray-100"
          >
            <ChevronLeft size={24} />
          </button>
          
          <button 
            onClick={nextSlide}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg p-3 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300 hover:bg-gray-50 border border-gray-100"
          >
            <ChevronRight size={24} />
          </button>

          {/* Sliding Track */}
          <div 
            className="flex transition-transform duration-700 ease-in-out gap-8"
            style={{ transform: `translateX(-${startIndex * (100 / visibleItems)}%)` }}
          >
            {products.map((product) => (
              <div 
                key={product.id} 
                className="flex-shrink-0 w-full md:w-[calc(25%-1.5rem)] flex flex-col group/card"
              >
                {/* Image Area */}
                <div className="relative overflow-hidden bg-[#F9F9F9] aspect-[4/5] mb-4 rounded-sm">
                  <img
                    src={product.image}
                    alt={product.name}
                    className="h-full w-full object-contain object-center group-hover/card:scale-105 transition-transform duration-700 ease-out mix-blend-multiply p-4"
                  />
                  
                  {/* Sale Badge */}
                  {product.sale && (
                    <span className="absolute top-2 left-2 bg-red-600 text-white text-[10px] font-bold px-2 py-1 uppercase tracking-wider z-10">
                      Sale
                    </span>
                  )}

                  {/* Quick Action Overlay (Optional Clinical Touch) */}
                  <div className="absolute bottom-0 left-0 right-0 bg-white/90 py-2 translate-y-full group-hover/card:translate-y-0 transition-transform duration-300 flex justify-center gap-4">
                     <Eye size={18} className="text-gray-600 hover:text-black cursor-pointer"/>
                     <ShoppingCart size={18} className="text-gray-600 hover:text-black cursor-pointer"/>
                  </div>
                </div>

                {/* Product Info */}
                <div className="flex-1 flex flex-col text-center">
                  <p className="text-[10px] text-gray-500 uppercase tracking-widest mb-1">
                    {product.vendor}
                  </p>
                  
                  <h3 className="text-sm font-medium text-gray-900 leading-snug mb-2 hover:text-yellow-600 transition-colors cursor-pointer">
                    {product.name}
                  </h3>

                  <p className="text-xs text-gray-500 mb-3">
                    {product.concern} <span className="mx-1">|</span> {product.size}
                  </p>

                  <div className="mt-auto mb-4">
                    <p className="text-xs text-gray-400 mb-1">MRP: Regular price</p>
                    <div className="flex justify-center items-center gap-2">
                      {product.price < product.mrp && (
                        <span className="text-sm text-gray-400 line-through">
                          ₹{product.mrp}.00
                        </span>
                      )}
                      <span className="text-sm font-bold text-gray-900">
                        ₹{product.price}.00
                      </span>
                    </div>
                  </div>

                  <button className="w-full bg-transparent border border-gray-200 text-gray-900 py-3 text-xs font-bold uppercase tracking-widest hover:bg-black hover:text-white hover:border-black transition-all duration-300 rounded-sm">
                    Add to Cart
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductSection;