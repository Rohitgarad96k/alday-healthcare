import React, { useState } from 'react';
import { Search, ShoppingBag, User, Menu, X } from 'lucide-react';

const Navbar = () => {
  const [activeMenu, setActiveMenu] = useState(null);

  // Data for the Mega Menus
  const menuData = {
    'HAIRCARE': {
      products: ['Shampoo', 'Conditioner', 'Hair Oil', 'Hair Serum', 'Hair Perfume'],
      concerns: ['Hair Growth', 'Hair Fall', 'Dandruff', 'Dry/Damaged Hair', 'Hair Loss'],
      ingredients: ['Rosemary', 'Onion', 'Coconut', 'Argan', 'Tea Tree', 'Castor'],
      image: 'https://images.unsplash.com/photo-1608248597279-f99d160bfbc8?auto=format&fit=crop&w=400&q=80'
    },
    'SKINCARE': {
      products: ['Face Wash', 'Face Toner', 'Face Serum', 'Moisturiser', 'Sunscreen'],
      concerns: ['Pigmentation', 'Acne', 'Ageing', 'Sun Protection', 'Sensitivity'],
      ingredients: ['Vitamin C', 'Salicylic Acid', 'Hyaluronic Acid', 'Neem', 'Rose'],
      image: 'https://images.unsplash.com/photo-1556228720-191738e4a2e5?auto=format&fit=crop&w=400&q=80'
    },
    'BODYCARE': {
      products: ['Body Wash', 'Body Scrub', 'Body Lotion', 'Body Oil', 'Soaps'],
      concerns: ['Body Acne', 'Dryness', 'Tanning', 'Stretch Marks'],
      ingredients: ['Coffee', 'Almond', 'Shea Butter', 'Cocoa', 'Lavender'],
      image: 'https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?auto=format&fit=crop&w=400&q=80'
    }
  };

  return (
    <div className="sticky top-0 z-50 bg-white">
      
      {/* 1. NOTIFICATION BAR (Matches Video Style) */}
      <div className="bg-[#F8F8F8] text-[#1A1A1A] text-[10px] md:text-xs font-bold tracking-[0.15em] text-center py-2.5 border-b border-gray-100">
        100% NATURAL NUTRITION &nbsp;|&nbsp; NO CHEMICALS &nbsp;|&nbsp; NO PRESERVATIVES
      </div>

      {/* 2. MAIN NAVIGATION */}
      <nav className="bg-white border-b border-gray-100 relative">
        <div className="max-w-[1400px] mx-auto px-6 h-20 flex items-center justify-between">
          
          {/* Logo */}
          <div className="flex items-center gap-2 z-20">
            <span className="text-2xl font-bold tracking-widest text-black">
              ALDAY<span className="font-light">HEALTH</span>
            </span>
            <div className="w-7 h-7 rounded-full border border-black flex items-center justify-center font-serif font-bold text-sm">
              A
            </div>
          </div>

          {/* Desktop Links (with Mega Menu Triggers) */}
          <div className="hidden lg:flex items-center h-full">
            {['HAIRCARE', 'SKINCARE', 'BODYCARE', 'GIFTING', 'RITUALS', 'EXPLORE'].map((item) => (
              <div 
                key={item}
                className="h-full flex items-center px-5 group cursor-pointer"
                onMouseEnter={() => menuData[item] && setActiveMenu(item)}
                onMouseLeave={() => setActiveMenu(null)}
              >
                <a 
                  href="#" 
                  className="text-xs font-bold text-gray-800 uppercase tracking-[0.15em] group-hover:text-[#C5A059] transition-colors relative"
                >
                  {item}
                  {/* Underline Effect */}
                  <span className="absolute bottom-[-4px] left-0 w-0 h-[2px] bg-[#C5A059] transition-all duration-300 group-hover:w-full"></span>
                </a>

                {/* 3. MEGA MENU DROPDOWN (Conditionally Rendered) */}
                {activeMenu === item && menuData[item] && (
                  <div className="absolute top-full left-0 w-full bg-white shadow-xl border-t border-gray-100 py-10 animate-fade-in z-50">
                    <div className="max-w-[1200px] mx-auto px-6 flex justify-between">
                      
                      {/* Column 1: Products */}
                      <div className="w-1/4">
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Products</h4>
                        <ul className="space-y-3">
                          {menuData[item].products.map((link) => (
                            <li key={link}>
                              <a href="#" className="text-sm text-gray-800 hover:text-[#C5A059] transition-colors font-medium">{link}</a>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Column 2: Concerns */}
                      <div className="w-1/4">
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Concerns</h4>
                        <ul className="space-y-3">
                          {menuData[item].concerns.map((link) => (
                            <li key={link}>
                              <a href="#" className="text-sm text-gray-800 hover:text-[#C5A059] transition-colors font-medium">{link}</a>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Column 3: Ingredients */}
                      <div className="w-1/4">
                        <h4 className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Ingredients</h4>
                        <ul className="space-y-3">
                          {menuData[item].ingredients.map((link) => (
                            <li key={link}>
                              <a href="#" className="text-sm text-gray-800 hover:text-[#C5A059] transition-colors font-medium">{link}</a>
                            </li>
                          ))}
                        </ul>
                      </div>

                      {/* Column 4: Feature Image */}
                      <div className="w-1/4 pl-10 border-l border-gray-100">
                         <div className="w-full h-64 overflow-hidden relative group/img">
                           <img 
                            src={menuData[item].image} 
                            alt={item} 
                            className="w-full h-full object-cover mix-blend-multiply group-hover/img:scale-105 transition-transform duration-700" 
                           />
                           <div className="absolute bottom-4 left-4">
                             <span className="bg-black text-white text-[10px] uppercase font-bold px-3 py-1">Bestseller</span>
                           </div>
                         </div>
                      </div>

                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Icons (Right) */}
          <div className="flex items-center space-x-6 text-gray-800 z-20">
            <Search strokeWidth={1.5} className="w-5 h-5 cursor-pointer hover:text-[#C5A059]" />
            <User strokeWidth={1.5} className="w-5 h-5 cursor-pointer hover:text-[#C5A059]" />
            <div className="relative">
              <ShoppingBag strokeWidth={1.5} className="w-5 h-5 cursor-pointer hover:text-[#C5A059]" />
              <span className="absolute -top-1 -right-1 bg-black text-white text-[9px] w-3.5 h-3.5 rounded-full flex items-center justify-center">0</span>
            </div>
            <Menu className="w-6 h-6 lg:hidden cursor-pointer" />
          </div>
        </div>
      </nav>
      
      {/* Overlay to dim the rest of the site when menu is open */}
      {activeMenu && (
        <div 
          className="fixed inset-0 top-[115px] bg-black/20 z-10 backdrop-blur-[2px] transition-opacity duration-300"
          onMouseEnter={() => setActiveMenu(null)}
        />
      )}
    </div>
  );
};

export default Navbar;