import React from 'react';
import { Star, CheckCircle } from 'lucide-react';

const Reviews = () => {
  const reviews = [
    { name: "Priyanshi Y.", title: "It's really worth hype", body: "My over all experience is so good", product: "Rosemary Oil Shots" },
    { name: "Aditya S.", title: "Oil shots review", body: "It really helped decreasing significant dandruff from my scalp", product: "Tea Tree Oil" },
    { name: "Dhanraj V.", title: "A great bodywash", body: "It has a rich, creamy consistency that feels more like a lotion than a soap.", product: "Lavender Body Wash" },
  ];

  return (
    <section className="py-20 bg-white border-t border-gray-100">
      <div className="max-w-[1400px] mx-auto px-6">
        
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-end mb-12">
          <h2 className="text-2xl font-bold text-brand-black">Real Reviews from Real Customers</h2>
          <div className="flex items-center gap-2 text-sm font-medium mt-4 md:mt-0">
             <div className="flex text-green-500">
               {[1,2,3,4,5].map(i => <Star key={i} size={16} fill="currentColor" />)}
             </div>
             <span>8190 Reviews</span>
          </div>
        </div>

        {/* Review Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {reviews.map((review, idx) => (
            <div key={idx} className="p-6 border border-gray-100 rounded-sm hover:shadow-lg transition-shadow">
               <div className="flex text-green-500 mb-3">
                 {[1,2,3,4,5].map(i => <Star key={i} size={14} fill="currentColor" />)}
               </div>
               <h3 className="font-bold text-gray-900 mb-2">{review.title}</h3>
               
               <div className="flex gap-4 mb-4">
                 <div className="w-12 h-16 bg-gray-100 flex-shrink-0">
                    <img src="https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=100" className="w-full h-full object-cover opacity-80" />
                 </div>
                 <p className="text-sm text-gray-500 italic">"{review.body}"</p>
               </div>

               <div className="flex items-center gap-2 mt-4 pt-4 border-t border-gray-50">
                 <span className="text-xs font-bold text-gray-900">{review.name}</span>
                 <span className="flex items-center text-[10px] text-gray-400">
                   <CheckCircle size={10} className="mr-1"/> Verified Buyer
                 </span>
               </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
};

export default Reviews;