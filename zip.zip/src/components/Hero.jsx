import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const slides = [
  {
    id: 1,
    tag: "New Launch",
    title: "Rosemary Oil Shots",
    subtitle: "Visible Hair Growth in 4 Weeks",
    features: ["Precise 20% Dose", "Promotes hair follicle", "Fights hair thinning"],
    image: "https://www.brillare.co.in/cdn/shop/files/Rosemary-Oil-Shots-For-Visible-Hair-Growth-Front-1_360x.jpg?v=1706698662", // Use the actual image URL if available
    bgColor: "bg-[#E8DFD6]", // The Beige from screenshot
    buttonText: "Shop Now"
  },
  {
    id: 2,
    tag: "Bestseller",
    title: "Vitamin C Face Serum",
    subtitle: "For Bright, Glowing Skin",
    features: ["10% Pure Vitamin C", "Reduces Pigmentation", "Boosts Collagen"],
    image: "https://www.brillare.co.in/cdn/shop/files/10_-Vitamin-C-Face-Serum-Front_360x.jpg?v=1706699151",
    bgColor: "bg-[#F3E9E2]", // Soft Peach/Pink
    buttonText: "Explore Range"
  },
  {
    id: 3,
    tag: "Clinical Care",
    title: "Hair Fall Control",
    subtitle: "Reduces Hair Fall in 15 Days",
    features: ["Onion & Bakuchiol", "Strengthens Roots", "Zero Dilution"],
    image: "https://www.brillare.co.in/cdn/shop/files/Onion-Oil-Shots-For-Hair-Fall-Reduction-Front-1_360x.jpg?v=1706698468",
    bgColor: "bg-[#E0E6E1]", // Soft Green
    buttonText: "View Kit"
  }
];

const Hero = () => {
  const [current, setCurrent] = useState(0);

  // Auto-scroll effect (changes every 5 seconds)
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrent((prev) => (prev === slides.length - 1 ? 0 : prev + 1));
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrent(current === slides.length - 1 ? 0 : current + 1);
  };

  const prevSlide = () => {
    setCurrent(current === 0 ? slides.length - 1 : current - 1);
  };

  return (
    <div className={`relative transition-colors duration-700 ease-in-out ${slides[current].bgColor} min-h-[500px] md:h-[600px] w-full overflow-hidden flex items-center`}>
      
      {/* Arrow Navigation (Hidden on mobile for cleaner look) */}
      <button onClick={prevSlide} className="absolute left-4 z-20 p-2 rounded-full bg-white/50 hover:bg-white hidden md:block transition-all">
        <ChevronLeft size={24} />
      </button>
      <button onClick={nextSlide} className="absolute right-4 z-20 p-2 rounded-full bg-white/50 hover:bg-white hidden md:block transition-all">
        <ChevronRight size={24} />
      </button>

      {/* Main Content Container */}
      <div className="max-w-[1400px] mx-auto px-6 w-full grid grid-cols-1 md:grid-cols-2 gap-10 items-center relative z-10">
        
        {/* Left: Text Content */}
        <div className="order-2 md:order-1 pb-10 md:pb-0 transition-opacity duration-500 ease-in-out">
          <span className="block text-sm md:text-base font-bold tracking-widest uppercase mb-4 text-gray-900">
            {slides[current].tag}
          </span>
          
          <h1 className="text-4xl md:text-6xl font-bold text-gray-900 mb-4 leading-tight">
            {slides[current].title}
          </h1>
          
          <p className="text-xl md:text-3xl font-light text-gray-800 mb-8">
             {slides[current].subtitle.split(' ').slice(0, 3).join(' ')} <br/>
            <span className="font-medium">{slides[current].subtitle.split(' ').slice(3).join(' ')}</span>
          </p>
          
          <div className="flex flex-wrap gap-3 text-sm font-medium text-gray-700 mb-8">
            {slides[current].features.map((feature, index) => (
              <React.Fragment key={index}>
                <span>{feature}</span>
                {index < slides[current].features.length - 1 && <span className="hidden sm:inline">|</span>}
              </React.Fragment>
            ))}
          </div>

          <button className="bg-black text-white px-8 py-3 rounded-sm text-sm font-bold uppercase tracking-widest hover:bg-gray-800 transition-all shadow-lg">
            {slides[current].buttonText}
          </button>
        </div>

        {/* Right: Image (Product) */}
        <div className="relative order-1 md:order-2 flex justify-center h-full">
           {/* Image animation key: changing the key forces React to re-trigger animation */}
          <img 
            key={current} 
            src={slides[current].image} 
            alt={slides[current].title} 
            className="object-contain h-[350px] md:h-[500px] mix-blend-multiply drop-shadow-2xl animate-fade-in-up"
          />
        </div>
      </div>

      {/* Pagination Dots */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 flex space-x-3 z-20">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrent(index)}
            className={`transition-all duration-300 rounded-full ${
              current === index ? 'w-8 h-1 bg-black' : 'w-2 h-1 bg-gray-400 hover:bg-gray-600'
            }`}
          />
        ))}
      </div>
    </div>
  );
};

export default Hero;