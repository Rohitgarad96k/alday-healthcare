import React from 'react';

const concerns = [
  { title: "Hair Growth", image: "https://images.unsplash.com/photo-1590439471364-192aa70c0b53?auto=format&fit=crop&w=300&q=80" },
  { title: "Hair Fall", image: "https://images.unsplash.com/photo-1585238342024-78d387f4a707?auto=format&fit=crop&w=300&q=80" },
  { title: "Dandruff", image: "https://images.unsplash.com/photo-1580618672591-eb180b1a973f?auto=format&fit=crop&w=300&q=80" },
  { title: "Dry & Damaged", image: "https://images.unsplash.com/photo-1522337660859-02fbefca4702?auto=format&fit=crop&w=300&q=80" },
  { title: "Pigmentation", image: "https://images.unsplash.com/photo-1616394584738-fc6e612e71b9?auto=format&fit=crop&w=300&q=80" },
  { title: "Acne Control", image: "https://images.unsplash.com/photo-1556228720-191738e4a2e5?auto=format&fit=crop&w=300&q=80" },
];

const ShopByConcern = () => {
  return (
    <section className="bg-white py-16 border-t border-gray-100">
      <div className="max-w-[1400px] mx-auto px-6">
        <h2 className="text-2xl md:text-3xl font-bold text-center text-brand-black uppercase tracking-widest mb-12">
          Shop By Concern
        </h2>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 text-center">
          {concerns.map((item, index) => (
            <div key={index} className="group cursor-pointer flex flex-col items-center">
              <div className="w-28 h-28 md:w-32 md:h-32 rounded-full overflow-hidden mb-4 border-2 border-transparent group-hover:border-brand-gold transition-all duration-300">
                <img 
                  src={item.image} 
                  alt={item.title} 
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
              </div>
              <h3 className="text-sm font-medium text-gray-900 uppercase tracking-wide group-hover:text-brand-gold">
                {item.title}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ShopByConcern;