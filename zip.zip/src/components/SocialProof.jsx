import React from 'react';
import { Droplets, ShieldCheck, Leaf } from 'lucide-react';

const SocialProof = () => {
  // Define logos once to map them easily
  const logos = [
    { name: "FEMINA", style: "font-serif font-bold" },
    { name: "GRAZIA", style: "font-serif font-bold" },
    { name: "VOGUE", style: "font-serif font-bold italic" },
    { name: "ELLE", style: "font-serif font-bold" },
    { name: "COSMOPOLITAN", style: "font-sans font-bold" }, // Added one more for length
    { name: "HARPERS BAZAAR", style: "font-serif font-bold" }
  ];

  return (
    <div className="bg-white pb-20 overflow-hidden"> 
      
      {/* 1. CELEBS FAVORITE */}
      <section className="py-20 text-center">
        <h2 className="text-2xl font-bold uppercase tracking-widest mb-12">Celebs Favorite</h2>
        
        <div className="flex justify-center gap-6 mb-10 px-4">
          {[1,2,3,4,5].map((i) => (
            <div key={i} className={`rounded-full overflow-hidden border-2 cursor-pointer transition-all ${i === 3 ? 'w-24 h-24 border-brand-gold scale-110 shadow-lg' : 'w-16 h-16 border-transparent opacity-50 hover:opacity-100'}`}>
              <img src={`https://i.pravatar.cc/150?img=${i+10}`} alt="Celeb" className="w-full h-full object-cover" />
            </div>
          ))}
        </div>

        <div className="max-w-3xl mx-auto px-6">
          <span className="text-4xl text-gray-300 font-serif">“</span>
          <p className="text-gray-600 leading-relaxed text-lg -mt-4 mb-6">
            The wide range of products available in the personal care segment confuses consumers. 
            I am happy to be the face of Brillare, a home grown brand that is making it easier 
            for consumers to choose 100% natural products with zero dilution promise.
          </p>
          <p className="font-bold text-gray-900 uppercase tracking-widest">— Vaani Kapoor</p>
        </div>
      </section>

      {/* 2. INFINITE SCROLLING PRESS LOGOS */}
      <div className="border-t border-b border-gray-100 bg-gray-50/50 py-10 relative">
        <div className="overflow-hidden w-full">
          {/* The Wrapper with the 'animate-scroll' class */}
          <div className="animate-scroll">
            
            {/* Set 1: Original List */}
            <div className="flex w-1/2 justify-around items-center px-10 gap-16 opacity-40 grayscale hover:opacity-80 transition-opacity duration-300">
               {logos.map((logo, idx) => (
                 <h3 key={`set1-${idx}`} className={`text-4xl whitespace-nowrap ${logo.style}`}>
                   {logo.name}
                 </h3>
               ))}
            </div>

            {/* Set 2: Duplicate List (For Seamless Loop) */}
            <div className="flex w-1/2 justify-around items-center px-10 gap-16 opacity-40 grayscale hover:opacity-80 transition-opacity duration-300">
               {logos.map((logo, idx) => (
                 <h3 key={`set2-${idx}`} className={`text-4xl whitespace-nowrap ${logo.style}`}>
                   {logo.name}
                 </h3>
               ))}
            </div>

          </div>
        </div>
      </div>

      {/* 3. VALUES */}
      <div className="py-20 bg-white">
        <div className="text-center mb-16">
           <h2 className="text-2xl font-bold uppercase tracking-widest">Brillare Values</h2>
        </div>

        <div className="max-w-[1200px] mx-auto grid grid-cols-1 md:grid-cols-3 gap-12 px-6 text-center">
          <div className="flex flex-col items-center group">
            <div className="mb-6 p-4 rounded-full bg-gray-50 group-hover:bg-green-50 transition-colors">
              <Droplets strokeWidth={1} size={40} className="text-gray-900 group-hover:text-green-700"/>
            </div>
            <h4 className="font-bold uppercase tracking-wide mb-3">Transparency</h4>
            <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
              We believe in declaring all our ingredients upfront, so you know what's inside the product.
            </p>
          </div>
          
          <div className="flex flex-col items-center group">
             <div className="mb-6 p-4 rounded-full bg-gray-50 group-hover:bg-green-50 transition-colors">
              <Leaf strokeWidth={1} size={40} className="text-gray-900 group-hover:text-green-700"/>
            </div>
            <h4 className="font-bold uppercase tracking-wide mb-3">Results</h4>
            <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
              Made with super potent ingredients at required levels for high grade performance.
            </p>
          </div>

          <div className="flex flex-col items-center group">
             <div className="mb-6 p-4 rounded-full bg-gray-50 group-hover:bg-green-50 transition-colors">
              <ShieldCheck strokeWidth={1} size={40} className="text-gray-900 group-hover:text-green-700"/>
            </div>
            <h4 className="font-bold uppercase tracking-wide mb-3">Safety</h4>
            <p className="text-sm text-gray-500 leading-relaxed max-w-xs">
              Our products are made with high percentage of natural ingredients, without any harmful chemicals.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};

export default SocialProof;