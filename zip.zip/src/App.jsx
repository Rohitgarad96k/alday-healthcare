// src/App.jsx
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import ProductSection from './components/ProductSection'; // Grid we made earlier
import ShopByConcern from './components/ShopByConcern'; // Circular icons
import BundleSection from './components/BundleSection'; // NEW: Complex Kit
import SocialProof from './components/SocialProof'; // NEW: Celebs & Values
import Reviews from './components/Reviews'; // NEW: Real Reviews
import Footer from './components/Footer'; // NEW: Updated Footer

function App() {
  return (
    <div className="font-sans antialiased text-gray-900 bg-white">
      <Navbar />
      <Hero />
      
      {/* 1. Shop By Concern (Icons) */}
      <ShopByConcern />
      
      {/* 2. Text Break */}
      <div className="text-center py-16 px-4">
        <h2 className="text-2xl md:text-4xl font-bold font-serif text-brand-black mb-4">
          Better Ingredients, Better Results!
        </h2>
        <p className="max-w-2xl mx-auto text-gray-500 leading-relaxed">
          We meticulously select high-performance, natural ingredients for our products, 
          ensuring they are free from harmful chemicals.
        </p>
      </div>

      {/* 3. Main Product Grid */}
      <ProductSection />
      
      {/* 4. The Complex Bundle Sections */}
      <BundleSection />

      {/* 5. Celebs & Values */}
      <SocialProof />

      {/* 6. Reviews */}
      <Reviews />

      {/* 7. Footer */}
      <Footer />
    </div>
  )
}

export default App;