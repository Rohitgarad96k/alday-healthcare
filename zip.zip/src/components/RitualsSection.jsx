import React from 'react';

const kits = [
  {
    title: "Ultimate Rosemary Hair Growth Kit",
    price: "₹2,385",
    mrp: "₹3,180",
    image: "https://images.unsplash.com/photo-1556228578-8d8448ad1d4d?auto=format&fit=crop&w=600&q=80", // Placeholder
    save: "Save 25%"
  },
  {
    title: "Complete Hair Fall Control Kit",
    price: "₹1,599",
    mrp: "₹2,285",
    image: "https://images.unsplash.com/photo-1629198688000-71f23e745b6e?auto=format&fit=crop&w=600&q=80",
    save: "Save 30%"
  }
];

const RitualsSection = () => {
  return (
    <section className="bg-[#F9F5F1] py-20">
      <div className="max-w-[1400px] mx-auto px-6">
        <h2 className="text-3xl font-bold text-center text-brand-black uppercase tracking-widest mb-2">
          Complete Rituals
        </h2>
        <p className="text-center text-gray-500 mb-12 font-light">
          Science-backed regimens for faster results
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          {kits.map((kit, index) => (
            <div key={index} className="bg-white p-6 md:p-8 flex flex-col md:flex-row items-center gap-8 shadow-sm hover:shadow-md transition-shadow">
              {/* Image Side */}
              <div className="w-full md:w-1/2 relative bg-gray-50 aspect-square flex items-center justify-center">
                <img src={kit.image} alt={kit.title} className="max-h-[80%] object-contain mix-blend-multiply" />
                <span className="absolute top-2 left-2 bg-brand-black text-white text-[10px] uppercase font-bold px-2 py-1">
                  {kit.save}
                </span>
              </div>

              {/* Text Side */}
              <div className="w-full md:w-1/2 text-left">
                <h3 className="text-xl font-bold text-gray-900 mb-2 leading-snug">
                  {kit.title}
                </h3>
                <div className="flex items-center gap-3 mb-6">
                  <span className="text-gray-400 line-through text-sm">{kit.mrp}</span>
                  <span className="text-lg font-bold text-brand-black">{kit.price}</span>
                </div>
                
                <button className="w-full bg-brand-black text-white py-3 text-xs font-bold uppercase tracking-widest hover:bg-gray-800 transition-colors rounded-sm">
                  Add Kit To Cart
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default RitualsSection;